1. Import zipped project into Eclipse with maven inbuilt.
2. Right click on the project and run as Junit Test to run the test class and view test case results.
3. Right click on the project and run as Maven Test to execute JaCoCo plugin which will generate html coverage reports in the target folder of the project.

